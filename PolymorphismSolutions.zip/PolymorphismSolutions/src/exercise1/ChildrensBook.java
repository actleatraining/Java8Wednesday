package exercise1;

public class ChildrensBook extends Book {
    private String recommendedAgeInfo;

    public ChildrensBook(long productId, String title, String author, int price, String recommendedAgeInfo) {
        super(productId, author, title, price); // When the input arguments differ in a Subclass constructor it has to call the constructor of the Superclass
        this.recommendedAgeInfo = recommendedAgeInfo;
    }

    public String getRecommendedAgeInfo() {
        return recommendedAgeInfo;
    }

    public void setRecommendedAgeInfo(String recommendedAgeInfo) {
        this.recommendedAgeInfo = recommendedAgeInfo;
    }

    // Should ChildrensBook have its own description method?
    // To access title and author from here they need to be protected instead of private!
    /*
    public void description() {
        System.out.println("Childrens Book with product id: " + productId + ", Price: " + price + ", Title: " + title + ", Author: " + author + " RecommendedAgeInfo: " + recommendedAgeInfo);
    }
    */
}
