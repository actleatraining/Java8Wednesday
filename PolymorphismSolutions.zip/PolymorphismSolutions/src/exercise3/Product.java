package exercise3;

public class Product {
    protected long productId;
    protected int price;

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void description() {
        System.out.println("Product id: " + productId + ", Price: " + price);
    }
}
