package exercise2;

public class VideoGame extends Product {
    private String title;
    private String brand;

    public VideoGame(long productId, String title, String brand, int price) {
        this.productId = productId;
        this.title = title;
        this.brand = brand;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    // By not implementing a method, VideoGame inherits from Product
    /*
    public void description() {
        System.out.println("Video game with product id: " + productId + ", Price: " + price +
                ", Title: " + title + ", Brand: " + brand);
    }
    */
}