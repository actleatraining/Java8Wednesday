package exercise2;

public class Movie extends Product {
    private String title;
    private String director;

    public Movie(long productId, String title, int price, String director) {
        this.productId = productId;
        this.title = title;
        this.price = price;
        this.director = director;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void description() {
        System.out.println("Movie with product id: " + productId + ", Price: " + price +
                ", Title: " + title + ", Director: " + director);
    }
}