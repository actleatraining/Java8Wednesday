package com.demo1;

public class Dog implements Animal {

    public Dog() {
    }

    // If the Dog does not override the eat method it cannot implement the interface
    @Override
    public void eat() {
        System.out.println("Dog is eating");
    }

    public void wagTail() {
        System.out.println("Dog is wagging the tail");
    }
}
