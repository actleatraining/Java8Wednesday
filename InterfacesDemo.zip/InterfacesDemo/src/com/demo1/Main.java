package com.demo1;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        Dog dog = new Dog();
        Cat cat = new Cat();

        System.out.println("--Feeding all animals--");
        Animal[] animals = new Animal[2];
        animals[0] = cat;
        animals[1] = dog;

        for (Animal a : animals) {
            feed(a);
        }
    }

    // Method accepts an input argument of any class, if it implements Animal, doesn't need to know the class - loose coupling!
    private static void feed(Animal animal) {
        animal.eat();
    }
}
