package com.demo1;

// Cat is now implementing the interface instead of extending the abstract superclass
public class Cat implements Animal {

    public Cat() {
    }

    @Override
    public void eat() {
        System.out.println("Cat is eating");
    }

    public void purr() {
        System.out.println("Miao");
    }
}
