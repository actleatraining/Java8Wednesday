package com.demo1;

// Interface
public interface Animal {

    // Methods are by default abstract
    void eat();
}
