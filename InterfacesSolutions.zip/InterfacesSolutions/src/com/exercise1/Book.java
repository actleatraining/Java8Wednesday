package com.exercise1;

public class Book implements Product {
    protected long productId; // needs to be in Book instead of in Product
    protected int price; // needs to be in Book instead of in Product
    private String title;
    private String author;

    public Book(long productId, String author, String title, int price) {
        this.productId = productId;
        this.title = title;
        this.author = author;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void description() {
        System.out.println("Book with product id: " + productId + ", Price: " + price + ", Title: " + title + ", Author: " + author);
    }

}