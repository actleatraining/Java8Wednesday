package com.exercise1;

public class Movie implements Product {
    protected long productId; // needs to be in Book instead of in Product
    protected int price; // needs to be in Book instead of in Product
    private String title;
    private String director;

    public Movie(long productId, String title, int price, String director) {
        this.productId = productId;
        this.title = title;
        this.price = price;
        this.director = director;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void description() {
        System.out.println("Movie with product id: " + productId + ", Price: " + price +
                ", Title: " + title + ", Director: " + director);
    }
}