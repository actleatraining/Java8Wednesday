package com.exercise1;

public class VideoGame implements Product {
    protected long productId; // needs to be in Book instead of in Product
    protected int price; // needs to be in Book instead of in Product
    private String title;
    private String brand;

    public VideoGame(long productId, String title, String brand, int price) {
        this.productId = productId;
        this.title = title;
        this.brand = brand;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    // Now, VideoGame really needs its own implementation of the description method
    public void description() {
        System.out.println("Movie with product id: " + productId + ", Price: " + price +
                ", Title: " + title + ", Brand: " + brand);
    }
}