package com.exercise1;

public interface Product {
    // When Product becomes an interface all functionality below needs to be moved (or in the case of the description method - needs to be abstract)
    /*
    protected long productId;
    protected int price;

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public abstract void description();

    */

    // Only this abstract method stays in the interface (but normally you don't use an access modifier and you don't need the abstract keyword in interfaces
    void description();
}
