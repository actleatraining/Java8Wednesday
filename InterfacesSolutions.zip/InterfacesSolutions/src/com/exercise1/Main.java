package com.exercise1;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        Book lordOfTheRings = new Book(123, "The Lord of the Rings", "J R R Tolkien", 299);

        Book childrensBook = new ChildrensBook(124, "Lindgren", "Pippi Longstocking", 199, "For children of all ages");

        Movie movie = new Movie(127, "Ghostbusters", 179, "Ivan Reitman");

        VideoGame videoGame = new VideoGame(130, "Pac-man", "Playstation 5", 799);

        Product[] products = new Product[4];
        products[0] = lordOfTheRings;
        products[1] = childrensBook;
        products[2] = movie;
        products[3] = videoGame;

        for (Product product : products) {
            product.description();
        }
    }
}
