package demo2;

public class Animal {

    protected String name; // protected is ok, but private is not ok!

    public Animal(String name) {
        this.name = name;
    }

    public void eat() {
        System.out.println("Animal is eating");
    }

    public String getName() {
        return name;
    }
}
