package demo2;

public class Dog extends Animal {

    public Dog(String name) {
        super(name);
    }

    public void wagTail() {
        System.out.println(name + " is wagging the tail");
    }
}
