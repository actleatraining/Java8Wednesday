package demo2;

public class Main {

    public static void main(String[] args) {


        Dog dog = new Dog("Pluto");

        Cat cat = new Cat("Garfield");

        Animal[] animals = new Animal[2];
        animals[0] = cat;
        animals[1] = dog;

        for (Animal a : animals) {
            //a.wagTail(); // Can't call wagTail since a is handled as an Animal type
            if (a instanceof Dog) {
                Dog d = (Dog)a;
                d.wagTail();
            }
            else if (a instanceof Cat) {
                Cat c = (Cat)a;
                c.purr();
            }
        }


    }
}
