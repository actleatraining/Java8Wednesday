package demo1;

public class Main {

    public static void main(String[] args) {

        Dog dog = new Dog("Pluto");

        Cat cat = new Cat("Garfield");

        Animal[] animals = new Animal[2];
        animals[0] = cat;
        animals[1] = dog;

        for (Animal a : animals) {
            System.out.println(a.name);
        }
    }
}
