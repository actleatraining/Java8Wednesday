package demo3;

public class Dog extends Animal {

    public Dog() {
    }

    @Override
    public void eat() {
        System.out.println("Dog is eating");
    }

    public void wagTail() {
        System.out.println("Dog is wagging the tail");
    }
}
