package demo3;

public class Main {

    public static void main(String[] args) {

        Cat cat = new Cat();
        cat.eat();
        cat.purr();

        Dog dog = new Dog();
        dog.eat();
        dog.wagTail();

        Horse horse = new Horse();
        horse.eat();
        horse.kick();

        Pudel pudel = new Pudel();
        pudel.eat();
        pudel.wagTail();

        // Polymorphism
        Animal dogAnimal = new Dog();
        dogAnimal.eat();
        //dogAnimal.wagTail(); // can't access the wagTail inside the Dog through an Animal reference

        Dog dog2 = (Dog)dogAnimal; // Casting the object to a Dog reference
        dog2.eat();
        dog2.wagTail(); // now wagTail is accessible through a Dog reference

        Animal animal = dog2;
        Dog dog3 = (Dog)animal;
        dog3.wagTail(); // it's here again! It doesn't disappear when cast to an Animal, int's just not accessible

        // Benefits of handling objects on a more general level

        System.out.println("--Feeding all animals--");
        Animal[] animals = new Animal[4];
        animals[0] = cat;
        animals[1] = dog;
        animals[2] = horse;
        animals[3] = pudel;

        for (Animal a : animals) {
            a.eat();
        }

    }
}
