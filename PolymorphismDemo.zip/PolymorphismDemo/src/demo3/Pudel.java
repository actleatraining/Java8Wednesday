package demo3;

public class Pudel extends Dog { // Yes, you are right, it should be poodle in english

    public Pudel() {
    }

    @Override
    public void eat() {
        System.out.println("Pudel is eating");
    }

    @Override
    public void wagTail() {
        System.out.println("Pudel is wagging the tail");
    }
}
