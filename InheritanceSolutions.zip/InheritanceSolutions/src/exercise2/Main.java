package exercise2;

public class Main {

    public static void main(String[] args) {

        Book lordOfTheRings = new Book(123, "The Lord of the Rings", "J R R Tolkien", 299);

        Book childrensBook = new ChildrensBook(124, "Lindgren", "Pippi Longstocking", 199, "For children of all ages");

        Movie movie = new Movie(127, "Ghostbusters", "Comedy", 179, "Ivan Reitman");

        VideoGame videoGame = new VideoGame(130, "Pac-man", "Playstation 5", 799);
    }
}
