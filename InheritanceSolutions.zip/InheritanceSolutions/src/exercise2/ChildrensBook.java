package exercise2;

public class ChildrensBook extends Book {
    private String recommendedAgeInfo;

    public ChildrensBook(long productId, String title, String author, int price, String recommendedAgeInfo) {
        super(productId, author, title, price); // When the input arguments differ in a Subclass constructor it has to call the constructor of the Superclass
        this.recommendedAgeInfo = recommendedAgeInfo;
    }

    public String getRecommendedAgeInfo() {
        return recommendedAgeInfo;
    }

    public void setRecommendedAgeInfo(String recommendedAgeInfo) {
        this.recommendedAgeInfo = recommendedAgeInfo;
    }
}
