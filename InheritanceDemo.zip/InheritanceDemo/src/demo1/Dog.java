package demo1;

// Dog extends Animal - the Subclass points to its Superclass
public class Dog extends Animal{

    public Dog() {
    }

    public void wagTail() {
        System.out.println("Dog is wagging the tail");
    }

    // When created the Dog object will also include the eat method inherited from Animal
}
