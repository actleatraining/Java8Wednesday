package demo1;

// The Superclass does not point to its Subclass
public class Animal {

    public Animal() {
    }

    // The eat method will be inherited by the Subclass
    public void eat() {
        System.out.println("Animal is eating");
    }
}
