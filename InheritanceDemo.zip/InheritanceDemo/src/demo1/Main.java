package demo1;

public class Main {

    public static void main(String[] args) {

        Animal animal = new Animal();
        animal.eat();

        Dog dog = new Dog();
        dog.wagTail();
        dog.eat();

    }
}
