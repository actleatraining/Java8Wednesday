package demo5;

import demo4.Animal;

public class Main {

    public static void main(String[] args) {

        demo4.Animal animal = new Animal("Pluto");
        animal.eat();

        Dog dog = new Dog();
        dog.wagTail();
        dog.eat();
    }
}
