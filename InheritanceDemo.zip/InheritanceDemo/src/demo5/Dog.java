package demo5;

// Dog extends Animal - the Subclass points to its Superclass
public class Dog extends Animal {

    public Dog() {
        super("default name"); // If the empty constructor is missing in the superclass, the subclass must call a specifik constructor with super
    }

    public void wagTail() {
        System.out.println(name + "Dog is wagging the tail");
    }

    // When created the Dog object will also include the eat method inherited from Animal
}
