package demo4;

public class Animal {

    String name;

    // If the empty constructor is removed in the superclass we have a problem in the subclass
    //public Animal() {
    //}

    public Animal(String name) {
        this.name = name;
    }

    public void eat() {
        System.out.println("Animal is eating");
    }
}
