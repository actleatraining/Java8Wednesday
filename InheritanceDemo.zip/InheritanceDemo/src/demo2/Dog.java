package demo2;

public class Dog extends Animal {

    public Dog() {
    }

    // Dog overrides the eat method from Animal (the @Override annotation is not mandatory)
    @Override
    public void eat() {
        System.out.println("Dog is eating");
    }

    public void wagTail() {
        System.out.println("Dog is wagging the tail");
    }
}
