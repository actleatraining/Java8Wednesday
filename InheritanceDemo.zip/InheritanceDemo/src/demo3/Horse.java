package demo3;

public class Horse extends Animal {

    public Horse() {
    }

    @Override
    public void eat() {
        System.out.println("Horse is eating");
    }

    public void kick() {
        System.out.println("Horse is kicking");
    }
}
