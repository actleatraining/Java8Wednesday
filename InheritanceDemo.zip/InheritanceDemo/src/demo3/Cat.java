package demo3;

public class Cat extends Animal {

    public Cat() {
    }

    @Override
    public void eat() {
        System.out.println("Cat is eating");
    }

    public void purr() {
        System.out.println("Miao");
    }
}
