package demo1;

// Making the Animal class abstract by adding the keyword abstract before the class
public abstract class Animal {

    public Animal() {
    }

    public void eat() {
        System.out.println("Animal is eating");
    }
}
