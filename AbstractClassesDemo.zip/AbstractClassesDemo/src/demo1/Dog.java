package demo1;

public class Dog extends Animal {

    public Dog() {
    }

    public void wagTail() {
        System.out.println("Dog is wagging the tail");
    }
}
