package demo1;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        // No difference to the Dog now when it inherits from an abstract class
        Dog dog = new Dog();
        dog.eat(); // Dog inherits the eat method from the abstract Superclass Animal
        dog.wagTail();

        Cat cat = new Cat();
        cat.eat(); // Cat overrides the eat method from the abstract Superclass Animal
        cat.purr();

        // But it is not possible to instansiate an object from the abstract class
        //Animal animal = new Animal();

        // But then - what is an animal that is not any of the subclasses?

        // The abstract superclass can be used as a reference type
        Animal animalDog = new Dog();

        System.out.println("--Feeding all animals--");
        Animal[] animals = new Animal[2];
        animals[0] = cat;
        animals[1] = dog;

        // Treating all animals generally by using the abstract Superclass as reference type
        for (Animal a : animals) {
            a.eat(); // See how Dog is inheriting the method from the Superclass, but Cat is overriding!
        }
    }
}
