package demo2;

// The Dog has to override the abstract method eat from Animal, it is not given an implementation but is forced to implement its own
public class Dog extends Animal {

    public Dog() {
    }

    // If the Dog does not override the eat method it cannot inherit from Animal
    @Override
    public void eat() {
        System.out.println("Dog is eating");
    }

    public void wagTail() {
        System.out.println("Dog is wagging the tail");
    }

    // Cannot override a final method in the Superclass
    /*
    @Override
    public void sleep() {
        System.out.println("Dog is sleeping");
    }
    */
}
