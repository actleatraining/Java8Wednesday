package demo2;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        Dog dog = new Dog();
        Cat cat = new Cat();

        System.out.println("--Feeding all animals--");
        Animal[] animals = new Animal[2];
        animals[0] = cat;
        animals[1] = dog;

        for (Animal a : animals) {
            a.eat(); // all implementations are in the Subclass, the method is not inherited from the Animal class
            // But, by having it as an abstract method all Subclasses are forced to implement it
            // And just like that, it is possible to call the specific implementations from a Superclass reference!
        }
    }
}
