package demo2;

// Making the Animal class abstract by adding the keyword abstract before the class
public abstract class Animal {

    public Animal() {
    }

    /*
    public void eat() {
        System.out.println("Animal is eating");
    }
    */

    // Making the eat method abstract
    public abstract void eat();

    // Creating a final sleep method (cannot be overridden in Subclasses)
    public final void sleep() {
        System.out.println("Animal is sleeping");
    }
}
