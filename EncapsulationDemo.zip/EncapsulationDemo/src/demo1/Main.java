package demo1;

public class Main {
    public static void main(String[] args) {
        /*
        Dog dog1 = new Dog();
        dog1.name = "Pluto";
        dog1.age = 93;

        Dog dog2 = new Dog();
        dog2.name = "Chicco";
        dog2.age = 2;
        */

        // Creating an object in one line istead of three lines:
        Dog dog1 = new Dog("Pluto", 93);

        Dog dog2 = new Dog("Chicco", 2);

    }
}