package demo1;

public class Dog {
    String name;
    int age;

    // Constructor that initializes the instance variables directly when the object is created
    public Dog (String name, int age) {
        this.name = name;
        this.age = age;
    }

    // The default constructor is gone because another constructor is now defined
}
