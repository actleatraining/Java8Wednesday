package demo3;

public class Main {
    public static void main(String[] args) {

        Dog dog1 = new Dog("Pluto");
        dog1.setAge(93);

        Dog dog2 = new Dog("Chicco", 2);

        System.out.println("Dog1 - Name: " + dog1.getName() + " Age: " + dog1.getAge());
        System.out.println("Dog2 - Name: " + dog2.getName() + " Age: " + dog2.getAge());
    }
}