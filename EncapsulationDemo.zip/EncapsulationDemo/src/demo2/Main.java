package demo2;

public class Main {
    public static void main(String[] args) {

        Dog dog1 = new Dog();

        Dog dog2 = new Dog("Pluto");

        Dog dog3 = new Dog(93);

        Dog dog4 = new Dog("Chicco", 2);

        System.out.println("Dog1 - Name: " + dog1.name + " Age: " + dog1.age);
        System.out.println("Dog2 - Name: " + dog2.name + " Age: " + dog2.age);
        System.out.println("Dog3 - Name: " + dog3.name + " Age: " + dog3.age);
        System.out.println("Dog4 - Name: " + dog4.name + " Age: " + dog4.age);
    }
}