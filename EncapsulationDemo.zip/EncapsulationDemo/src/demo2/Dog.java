package demo2;

public class Dog {
    String name;
    int age;

    public Dog () {
        this.name = "default dog name"; // initializing with a default value
    }

    public Dog (String name) {
        this.name = name;
    }

    public Dog (int age) {
        this("", age); // refering to another constructor with the this keyword
    }

    public Dog (String name, int age) {
        this.name = name;
        this.age = age;
    }
}
