package exercise2;

public class Book {
    String title;
    String author;
    int price;

    public Book(String title) {
        this.title = title;
    }

    public Book(String title, String author) {
        this(title, author, 0);
    }

    public Book(String title, String author, int price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }
}
