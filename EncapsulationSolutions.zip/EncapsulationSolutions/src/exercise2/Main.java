package exercise2;

public class Main {
    public static void main(String[] args) {

        // Some information will be missing using these constructors
        Book lordOfTheRings = new Book("The Lord of the Rings");
        Book pippiLongstocking = new Book("Do you know Pippi Longstocking?", "Astrid Lindgren");
        Book javaBook = new Book("Head First Java", "Kathy Sierra", 712);

        Book[] books = new Book[3];
        books[0] = lordOfTheRings;
        books[1] = pippiLongstocking;
        books[2] = javaBook;

        for (Book book : books) {
            printBook(book);
        }
    }

    static void printBook(Book book) {
        System.out.println("Title: " + book.title + " Author: " + book.author + " Price: " + book.price);
    }
}