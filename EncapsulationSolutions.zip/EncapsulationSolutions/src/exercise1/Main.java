package exercise1;

public class Main {
    public static void main(String[] args) {
        /*
        Book lordOfTheRings = new Book();
        lordOfTheRings.title = "The Lord of the Rings";
        lordOfTheRings.author = "J R R Tolkien";
        lordOfTheRings.price = 299;

        Book pippiLongstocking = new Book();
        pippiLongstocking.title = "Do you know Pippi Longstocking?";
        pippiLongstocking.author = "Astrid Lindgren";
        pippiLongstocking.price = 315;

        Book javaBook = new Book();
        javaBook.title = "Head First Java";
        javaBook.author = "Kathy Sierra";
        javaBook.price = 712;
        */
        
        Book lordOfTheRings = new Book("The Lord of the Rings", "J R R Tolkien", 299);
        Book pippiLongstocking = new Book("Do you know Pippi Longstocking?", "Astrid Lindgren", 315);
        Book javaBook = new Book("Head First Java", "Kathy Sierra", 712);

        Book[] books = new Book[3];
        books[0] = lordOfTheRings;
        books[1] = pippiLongstocking;
        books[2] = javaBook;

        for (Book book : books) {
            printBook(book);
        }
    }

    static void printBook(Book book) {
        System.out.println("Title: " + book.title + " Author: " + book.author + " Price: " + book.price);
    }
}