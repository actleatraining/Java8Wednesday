package exercise3;

public class Main {
    public static void main(String[] args) {

        Book lordOfTheRings = new Book("The Lord of the Rings", "J R R Tolkien", 299);
        Book pippiLongstocking = new Book("Do you know Pippi Longstocking?", "Astrid Lindgren", 315);
        Book javaBook = new Book("Head First Java", "Kathy Sierra", 712);

        Book[] books = new Book[3];
        books[0] = lordOfTheRings;
        books[1] = pippiLongstocking;
        books[2] = javaBook;

        for (Book book : books) {
            printBook(book);
        }
    }

    static void printBook(Book book) {
        System.out.println("Title: " + book.getTitle() + " Author: " + book.getAuthor() + " Price: " + book.getPrice());
    }
}